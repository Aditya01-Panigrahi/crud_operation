from django.apps import AppConfig


class NetflixappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "NETFLIXAPP"
